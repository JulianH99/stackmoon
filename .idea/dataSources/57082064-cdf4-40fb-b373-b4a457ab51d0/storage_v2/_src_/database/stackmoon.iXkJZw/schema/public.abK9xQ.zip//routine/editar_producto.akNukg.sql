create function editar_producto(_cod_producto character varying, _cantidad_inventario integer, _precio integer, _ruta_imagen character varying, _sn_iva bit, _id_tipo_prod integer, _id_proveedor integer)
  returns boolean
language plpgsql
as $$
declare updated int;
begin

  update productos set
    cod_producto = _cod_producto,
    cantidad_inventario = _cantidad_inventario,
    precio = _precio,
    ruta_imagen = _ruta_imagen,
    sn_iva = _sn_iva,
    id_tipo_prod = _id_tipo_prod,
    id_proveedor = _id_proveedor
  where cod_producto = _cod_producto;

  get diagnostics updated = row_count;

  return updated > 0;
end;
$$;

alter function editar_producto(varchar, integer, integer, varchar, bit, integer, integer)
  owner to julian99;

