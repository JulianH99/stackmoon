create function editar_iva(_id_iva integer, _valor integer)
  returns boolean
language plpgsql
as $$
declare update_count int;
begin

  update ivas set valor = _valor where id_iva = _id_iva;
  get diagnostics update_count = row_count;

  raise notice 'updated % rows in ivas', update_count;

  return update_count > 0;

end;
$$;

alter function editar_iva(integer, integer)
  owner to julian99;

