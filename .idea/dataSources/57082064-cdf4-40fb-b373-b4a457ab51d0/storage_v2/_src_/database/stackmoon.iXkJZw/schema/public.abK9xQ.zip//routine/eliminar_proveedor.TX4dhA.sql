create function eliminar_proveedor(_id_proveedor integer)
  returns boolean
language plpgsql
as $$
declare
  update_count int;
begin

  update proveedores
  set activo = false
  where id_proveedor = _id_proveedor;


  get diagnostics update_count = row_count;

  return update_count > 0;

end;
$$;

alter function eliminar_proveedor(integer)
  owner to julian99;

