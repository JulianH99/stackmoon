create function guardar_proveedor(nombre character varying, correo character varying, telefono character varying, telefono2 character varying, celular character varying)
  returns boolean
language plpgsql
as $$
declare
  exts int;
  insert_count int;
begin

  insert into proveedores (
    nombre, correo, telefono, telefono2, celular, activo)
  values (nombre, correo, telefono, telefono2, celular, default);

  get diagnostics insert_count = row_count;

  return insert_count > 0;
end;
$$;

alter function guardar_proveedor(varchar, varchar, varchar, varchar, varchar)
  owner to julian99;

