create function eliminar_producto(_cod_producto character varying)
  returns boolean
language plpgsql
as $$
declare deleted integer;
begin

  update productos set activo = false where cod_producto = _cod_producto;

  get diagnostics deleted = row_count ;

  return deleted == 1;

end;
$$;

alter function eliminar_producto(varchar)
  owner to julian99;

