create function eliminar_producto(_id integer)
  returns boolean
language plpgsql
as $$
declare delete_count integer;
begin
  update tipos_producto set activo = false where id_tipo_producto = _id;
  get diagnostics delete_count = row_count;
  raise notice 'Deleted % rows from tipos_producto', delete_count;

  return delete_count == 1;
end;
$$;

alter function eliminar_producto(integer)
  owner to julian99;

