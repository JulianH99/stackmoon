create function editar_proveedor(_id_proveedor integer, _nombre character varying, _correo character varying, _telefono character varying, _telefono2 character varying, _celular character varying)
  returns boolean
language plpgsql
as $$
begin

  update proveedores
  set nombre  = _nombre,
    correo    = _correo,
    telefono  = _telefono,
    telefono2 = _telefono2,
    celular   = _celular
  where id_proveedor = _id_proveedor;

end;
$$;

alter function editar_proveedor(integer, varchar, varchar, varchar, varchar, varchar)
  owner to julian99;

