create function guardar_producto(_nombre character varying)
  returns boolean
language plpgsql
as $$
declare   uid  uuid;
  declare exts integer;
begin

  insert into tipos_producto (nombre) values (_nombre);
  get diagnostics exts = row_count;
  raise notice 'added % rows in tipos_producto', exts;

  return exts > 0;

end;
$$;

alter function guardar_producto(varchar)
  owner to julian99;

