create function guardar_factura(fecha_factura date, tipo_factura tipofactura, productos character varying[], cantidades integer[])
  returns boolean
language plpgsql
as $$
declare   exts    integer;
  declare fact_id integer;
begin

  insert into facturas (tipo_factura, fecha_factura)
  values (tipo_factura, fecha_factura)
      returning id_factura
        into fact_id;

  -- get affected rows and display
  get diagnostics exts = row_count;
  raise notice 'Affected rows where %', exts;

  for i in 1 .. array_upper(productos, 1) loop
    insert into det_facturas_productos (id_factura, cod_producto, cantidad_producto)
    values (fact_id, productos [ i ], cantidades [ i ]);
  end loop;

  return exts > 0;

end;
$$;

alter function guardar_factura(date, tipofactura, character varying [], integer [])
  owner to julian99;

