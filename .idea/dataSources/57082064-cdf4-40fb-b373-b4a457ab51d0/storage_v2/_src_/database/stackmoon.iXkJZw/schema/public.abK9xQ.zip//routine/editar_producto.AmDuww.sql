create function editar_producto(_id integer, _nombre character varying)
  returns boolean
language plpgsql
as $$
declare update_count integer;
begin

  update tipos_producto set nombre = _nombre where id_tipo_producto = _id;
  get diagnostics update_count = row_count;
  raise notice 'updated % rows in tipos_producto', update_count;

  return update_count > 0;

end;
$$;

alter function editar_producto(integer, varchar)
  owner to julian99;

