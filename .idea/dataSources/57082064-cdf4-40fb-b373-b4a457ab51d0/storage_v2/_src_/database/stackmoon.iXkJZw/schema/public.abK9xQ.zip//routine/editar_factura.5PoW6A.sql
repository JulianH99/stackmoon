create function editar_factura(id_factura integer, productos character varying[], cantidades integer[])
  returns boolean
language plpgsql
as $$
declare   delete_count integer;
  declare insert_count integer;
begin

  delete from det_facturas_productos where id_factura = id_factura;
  get diagnostics delete_count = row_count;
  raise notice 'deleted % products from invoice', delete_count;

  for i in 1 .. array_upper(productos, 1) loop
    insert into det_facturas_productos (id_factura, cod_producto, cantidad_producto)
    values (id_factura, productos [ i ], cantidades [ i ]);
  end loop;

  get diagnostics insert_count = row_count;
  raise notice 'inserted % rows in details', insert_count;

  return insert_count > 0;


end;
$$;

alter function editar_factura(integer, character varying [], integer [])
  owner to julian99;

