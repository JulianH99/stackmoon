create function guardar_producto(cod_producto character varying, cantidad_inventario integer, precio integer, ruta_imagen character varying, sn_iva bit, id_tipo_prod integer, id_proveedor integer)
  returns boolean
language plpgsql
as $$
declare
  exts integer;
begin

  insert into productos(
    cod_producto,
    cantidad_inventario,
    precio,
    ruta_imagen,
    sn_iva,
    id_tipo_prod,
    id_proveedor,
    activo
  ) values (
    cod_producto,
    cantidad_inventario,
    precio,
    ruta_imagen,
    sn_iva,
    id_tipo_prod,
    id_proveedor,
    default
  );


  get diagnostics exts = row_count;

  return exts > 0;

end;
$$;

alter function guardar_producto(varchar, integer, integer, varchar, bit, integer, integer)
  owner to julian99;

