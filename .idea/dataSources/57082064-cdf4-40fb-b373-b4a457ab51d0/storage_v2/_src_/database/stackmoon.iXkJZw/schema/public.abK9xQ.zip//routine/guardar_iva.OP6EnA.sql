create function guardar_iva(valor integer)
  returns boolean
language plpgsql
as $$
declare   exts integer;
begin


  insert into ivas (valor) values (valor);
  get diagnostics exts = row_count;
  raise notice 'added % rows in ivas', exts;

  return exts > 0;

end;
$$;

alter function guardar_iva(integer)
  owner to julian99;

